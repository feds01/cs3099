const expr = <T>(cb: () => T): T => cb();

export default expr;
