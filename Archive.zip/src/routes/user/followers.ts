import { z } from 'zod';
import express from 'express';
import Logger from '../../common/logger';
import * as error from '../../common/errors';
import Follower from '../../models/Follower';
import * as userUtils from '../../utils/users';
import registerRoute from '../../lib/requests';
import User, { IUser, IUserRole } from '../../models/User';
import { ModeSchema } from '../../validators/requests';

const router = express.Router({ mergeParams: true });

/**
 * @version v1.0.0
 * @method POST
 * @url api/user/<id>/follow
 * @example
 * https://af268.cs.st-andrews.ac.uk/api/user/616f115feb325663f8bce3a4/follow
 * >>> body: {}
 *
 * @description This route is used to follow a user. The router accepts a token
 * in the header and retrieves the current user id from the token, it also
 * accepts the followee's id which is specified in the url. Then it adds a
 * mapping of them to the database.
 *
 * @error {ALREADY_FOLLOWED} if the followee is already followed by the current user.
 * @error {SELF_FOLLOWING} if the user account is trying to follow itself.
 * @error {NON_EXISTENT_USER} if the specified user does not exist.
 *
 * @return response to client if mapping was created and added to the system.
 * */
registerRoute(router, '/:username/follow', {
    method: 'post',
    params: z.object({ username: z.string() }),
    body: z.object({}),
    query: z.object({ mode: ModeSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const user = await userUtils.transformUsernameIntoId(req, res);
        if (!user) return;

        const { id: followerId } = req.requester;

        // check if the user is already following the other user, if so
        // then exit early and don't create the new follower link.
        const follower = await User.findById(followerId).exec();

        if (!follower) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_USER,
            });
        }

        // if the user is trying to follow itself
        // Just return a NoContent since we don't need to create anything
        if (follower.id === user.id) {
            return res.status(204).json({
                status: 'ok',
            });
        }

        let mapping = { follower: follower.id, following: user.id };

        // check if the user is already following, if so, exit early and return
        // corresponding messages
        const doc = await Follower.findOne(mapping).exec();

        if (doc) {
            return res.status(401).json({
                status: 'error',
                message: error.ALREADY_FOLLOWED,
            });
        }

        const newFollow = new Follower(mapping);
        try {
            newFollow.save();

            return res.status(201).json({
                status: 'ok',
                message: 'Successfully followed user.',
            });
        } catch (e) {
            Logger.error(e);

            return res.status(500).json({
                status: 'error',
                message: error.INTERNAL_SERVER_ERROR,
            });
        }
    },
});

registerRoute(router, '/:username/follow', {
    method: 'delete',
    params: z.object({ username: z.string() }),
    query: z.object({ mode: ModeSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const user = await userUtils.transformUsernameIntoId(req, res);
        if (!user) return;

        const { id: followerId } = req.requester;

        // check if the user is already following the other user, if so
        // then exit early and don't create the new follower link.
        const follower = await User.findById(followerId).exec();

        if (!follower) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_USER,
            });
        }

        const link = await Follower.findOneAndDelete({
            follower: follower.id,
            following: user.id,
        }).exec();

        if (!link) {
            return res.status(404).json({
                status: 'ok',
                message: "User isn't following the other user",
            });
        }

        return res.status(200).json({
            status: 'ok',
            message: 'User was unfollowed',
        });
    },
});

registerRoute(router, '/:username/follow', {
    method: 'get',
    params: z.object({ username: z.string() }),
    query: z.object({ mode: ModeSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const user = await userUtils.transformUsernameIntoId(req, res);
        if (!user) return;

        const { id: followerId } = req.requester;

        // check if the user is already following the other user, if so
        // then exit early and don't create the new follower link.
        const follower = await User.findById(followerId).exec();

        if (!follower) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_USER,
            });
        }

        const link = await Follower.findOne({
            follower: follower.id,
            following: user.id,
        }).exec();

        if (!link) {
            return res.status(404).json({
                status: 'ok',
                following: false,
                message: "User isn't following the other user",
            });
        } else {
            return res.status(200).json({
                status: 'ok',
                following: true,
                message: 'User is following the other user',
            });
        }
    },
});

registerRoute(router, '/:username/followers', {
    method: 'get',
    params: z.object({ username: z.string() }),
    query: z.object({ mode: ModeSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const user = await userUtils.transformUsernameIntoId(req, res);
        if (!user) return;

        // TODO:(alex) Implement pagination for this endpoint since the current limit will
        //             be 50 documents.
        // https://medium.com/swlh/mongodb-pagination-fast-consistent-ece2a97070f3
        const result = await Follower.find({ following: user.id })
            .populate<{ follower: IUser }[]>('follower')
            .limit(50);

        const followers = result.map((link) =>
            User.project((link as typeof result[number]).follower),
        );

        return res.status(200).json({
            status: 'ok',
            data: {
                followers,
            },
        });
    },
});

registerRoute(router, '/:username/following', {
    method: 'get',
    params: z.object({ username: z.string() }),
    query: z.object({ mode: ModeSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const user = await userUtils.transformUsernameIntoId(req, res);
        if (!user) return;

        // TODO:(alex) Implement pagination for this endpoint since the current limit will
        //             be 50 documents.
        // https://medium.com/swlh/mongodb-pagination-fast-consistent-ece2a97070f3
        const result = await Follower.find({ follower: user.id })
            .populate<{ following: IUser }[]>('following')
            .limit(50)
            .exec();

        const followers = result.map((link) =>
            User.project((link as typeof result[number]).following),
        );

        return res.status(200).json({
            status: 'ok',
            data: {
                following: followers,
            },
        });
    },
});

export default router;
