import { z } from 'zod';
import express from 'express';
import mongoose from 'mongoose';
import Logger from '../../common/logger';
import * as error from '../../common/errors';
import Comment from '../../models/Comment';
import registerRoute from '../../lib/requests';
import { IUser, IUserRole } from '../../models/User';
import Review, { IReviewStatus } from '../../models/Review';
import { ObjectIdSchema } from '../../validators/requests';
import { ICommentCreationSchema } from '../../validators/comments';
import { IPublication } from '../../models/Publication';

const router = express.Router();

/**
 *
 */
registerRoute(router, '/review/:id/comment', {
    method: 'put',
    body: ICommentCreationSchema,
    query: z.object({}),
    params: z.object({ id: ObjectIdSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const { id } = req.params;
        const { id: owner } = req.requester;
        const { replying, filename, anchor, contents } = req.body;

        const review = await Review.findById(id)
            .populate<{ owner: IUser }>('owner')
            .populate<{ publication: IPublication }>('publication')
            .exec();

        // Check that the review exists and that the current commenter isn't trying
        // to publish comments on a non-public review. Only a review owner can comment
        // on a review whilst creating it.
        if (
            !review ||
            (review.status === 'started' &&
                (review.owner as unknown as IUser & { id: string }).id !== owner)
        ) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_REVIEW,
            });
        }

        // check that the publication isn't in draft mode...
        if (review.publication.draft) {
            return res.status(400).json({
                status: 'error',
                message: 'Cannot comment on a drafted publication.',
            });
        }

        // Check if the thread is replying to another comment
        let thread = new mongoose.Types.ObjectId();

        if (typeof replying !== 'undefined') {
            const replyingComment = await Comment.findById(replying).exec();

            if (!replyingComment) {
                return res.status(400).json({
                    status: 'error',
                    message: 'Attempt to reply on a non-existent comment',
                });
            }

            // Verify that the comment has a thread since it'll be created if it doesn't...
            if (typeof replyingComment.thread === 'undefined') {
                Logger.error('Comment selected for replying should have a thread id...');

                return res.status(500).json({
                    status: 'error',
                    message: error.INTERNAL_SERVER_ERROR,
                });
            }

            thread = new mongoose.Types.ObjectId(replyingComment.thread.toString());
        }

        // If either the filename or the anchor is present on the comment, we need
        // to check that they are valid for the current submission....
        if (typeof filename !== 'undefined') {
            if (typeof anchor !== 'undefined') {
                console.log('filename and anchor!');
            } else {
                console.log('just filename');
            }
        }

        const newComment = new Comment({
            filename,
            anchor,
            contents,
            replying,
            review: id,
            thread,
        });

        try {
            await newComment.save();

            return res.status(201).json({
                status: 'ok',
                message: 'Created comment.',
                comment: Comment.project(newComment),
            });
        } catch (e) {
            Logger.error(e);

            return res.status(500).json({
                status: 'error',
                message: error.INTERNAL_SERVER_ERROR,
            });
        }
    },
});

/**
 *
 */
registerRoute(router, '/review/:id/complete', {
    method: 'post',
    body: z.object({}),
    query: z.object({}),
    params: z.object({ id: ObjectIdSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const { id } = req.params;
        const { id: ownerId } = req.requester;

        const review = await Review.findById(id).exec();

        // verify that the review exists and the owner is trying to publish it...
        if (!review || review.owner.toString() !== ownerId) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_REVIEW,
            });
        }

        await review.update({ $set: { status: IReviewStatus.Completed } }).exec();

        return res.status(200).json({
            status: 'ok',
            message: 'Marked the review as complete.',
        });
    },
});

/**
 *
 */
registerRoute(router, '/review/:id', {
    method: 'get',
    query: z.object({}),
    params: z.object({ id: ObjectIdSchema }),
    permission: IUserRole.Default,
    handler: async (req, res) => {
        const { id } = req.params;
        const { id: ownerId } = req.requester;

        const review = await Review.findById(id).exec();

        // verify that the review exists and the owner is trying to publish it...
        if (!review || review.owner.toString() !== ownerId) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_REVIEW,
            });
        }

        return res.status(200).json({
            status: 'ok',
            review: Review.project(review),
        });
    },
});

/**
 *
 */
registerRoute(router, '/review/:id', {
    method: 'delete',
    query: z.object({}),
    params: z.object({ id: ObjectIdSchema }),
    permission: IUserRole.Administrator,
    handler: async (req, res) => {
        const { id } = req.params;

        // Delete the entire review and delete all the comments on the review...
        const review = await Review.findByIdAndDelete(id).exec();

        if (!review) {
            return res.status(404).json({
                status: 'error',
                message: error.NON_EXISTENT_REVIEW,
            });
        }

        await Comment.deleteMany({ review: review.id }).exec();

        return res.status(200).json({
            status: 'ok',
            message: 'Review is deleted.',
        });
    },
});

export default router;
