import React, { ReactElement } from 'react';

interface Props {}

// https://codesandbox.io/s/react-mde-latest-forked-f9ti5?file=/src/index.js
export default function CommentEditor({}: Props): ReactElement {
    return <div></div>;
}
